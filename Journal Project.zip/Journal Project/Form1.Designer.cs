﻿namespace Journal
{
    partial class JournalGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FileListBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CreateButton = new System.Windows.Forms.Button();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.rootFolder = new System.Windows.Forms.FolderBrowserDialog();
            this.PathBox = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.label2 = new System.Windows.Forms.Label();
            this.RemameButton = new System.Windows.Forms.Button();
            this.FolderButton = new System.Windows.Forms.Button();
            this.openFile = new System.Windows.Forms.Button();
            this.journalListBox = new System.Windows.Forms.ListBox();
            this.watcher = new System.IO.FileSystemWatcher();
            this.timeLabel = new System.Windows.Forms.Label();
            this.arLabel = new System.Windows.Forms.Label();
            this.lineNumLabel = new System.Windows.Forms.Label();
            this.lineTextLabel = new System.Windows.Forms.Label();
            this.rebuildButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.watcher)).BeginInit();
            this.SuspendLayout();
            // 
            // FileListBox
            // 
            this.FileListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.FileListBox.FormattingEnabled = true;
            this.FileListBox.ItemHeight = 25;
            this.FileListBox.Location = new System.Drawing.Point(17, 53);
            this.FileListBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.FileListBox.Name = "FileListBox";
            this.FileListBox.Size = new System.Drawing.Size(348, 329);
            this.FileListBox.Sorted = true;
            this.FileListBox.TabIndex = 0;
            this.FileListBox.SelectedIndexChanged += new System.EventHandler(this.FileListBox_Selected);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.label1.Location = new System.Drawing.Point(128, 3);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "Files";
            // 
            // CreateButton
            // 
            this.CreateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.CreateButton.Location = new System.Drawing.Point(17, 435);
            this.CreateButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.CreateButton.Name = "CreateButton";
            this.CreateButton.Size = new System.Drawing.Size(363, 61);
            this.CreateButton.TabIndex = 2;
            this.CreateButton.Text = "Create File";
            this.CreateButton.UseVisualStyleBackColor = true;
            this.CreateButton.Click += new System.EventHandler(this.CreateButton_Click);
            // 
            // DeleteButton
            // 
            this.DeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.DeleteButton.Location = new System.Drawing.Point(17, 508);
            this.DeleteButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(363, 61);
            this.DeleteButton.TabIndex = 3;
            this.DeleteButton.Text = "Delete File";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // PathBox
            // 
            this.PathBox.AutoSize = true;
            this.PathBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.PathBox.Location = new System.Drawing.Point(13, 594);
            this.PathBox.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.PathBox.Name = "PathBox";
            this.PathBox.Size = new System.Drawing.Size(160, 25);
            this.PathBox.TabIndex = 4;
            this.PathBox.Text = "Selected Folder: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.label2.Location = new System.Drawing.Point(694, 3);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 39);
            this.label2.TabIndex = 6;
            this.label2.Text = "Journal";
            // 
            // RemameButton
            // 
            this.RemameButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.RemameButton.Location = new System.Drawing.Point(391, 435);
            this.RemameButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.RemameButton.Name = "RemameButton";
            this.RemameButton.Size = new System.Drawing.Size(357, 61);
            this.RemameButton.TabIndex = 7;
            this.RemameButton.Text = "Rename File";
            this.RemameButton.UseVisualStyleBackColor = true;
            this.RemameButton.Click += new System.EventHandler(this.RemameButton_Click);
            // 
            // FolderButton
            // 
            this.FolderButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.FolderButton.Location = new System.Drawing.Point(391, 508);
            this.FolderButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.FolderButton.Name = "FolderButton";
            this.FolderButton.Size = new System.Drawing.Size(357, 62);
            this.FolderButton.TabIndex = 8;
            this.FolderButton.Text = "Journal Folder";
            this.FolderButton.UseVisualStyleBackColor = true;
            this.FolderButton.Click += new System.EventHandler(this.FolderButton_Click);
            // 
            // openFile
            // 
            this.openFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.openFile.Location = new System.Drawing.Point(761, 435);
            this.openFile.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.openFile.Name = "openFile";
            this.openFile.Size = new System.Drawing.Size(357, 61);
            this.openFile.TabIndex = 9;
            this.openFile.Text = "Open File";
            this.openFile.UseVisualStyleBackColor = true;
            this.openFile.Click += new System.EventHandler(this.openFile_Click);
            // 
            // journalListBox
            // 
            this.journalListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.journalListBox.FormattingEnabled = true;
            this.journalListBox.ItemHeight = 16;
            this.journalListBox.Location = new System.Drawing.Point(411, 95);
            this.journalListBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.journalListBox.Name = "journalListBox";
            this.journalListBox.Size = new System.Drawing.Size(708, 276);
            this.journalListBox.TabIndex = 11;
            // 
            // watcher
            // 
            this.watcher.EnableRaisingEvents = true;
            this.watcher.SynchronizingObject = this;
            // 
            // timeLabel
            // 
            this.timeLabel.AutoSize = true;
            this.timeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.timeLabel.Location = new System.Drawing.Point(417, 61);
            this.timeLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(65, 31);
            this.timeLabel.TabIndex = 12;
            this.timeLabel.Text = "time";
            // 
            // arLabel
            // 
            this.arLabel.AutoSize = true;
            this.arLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.arLabel.Location = new System.Drawing.Point(612, 61);
            this.arLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.arLabel.Name = "arLabel";
            this.arLabel.Size = new System.Drawing.Size(46, 31);
            this.arLabel.TabIndex = 13;
            this.arLabel.Text = "a/r";
            // 
            // lineNumLabel
            // 
            this.lineNumLabel.AutoSize = true;
            this.lineNumLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lineNumLabel.Location = new System.Drawing.Point(756, 61);
            this.lineNumLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lineNumLabel.Name = "lineNumLabel";
            this.lineNumLabel.Size = new System.Drawing.Size(115, 31);
            this.lineNumLabel.TabIndex = 14;
            this.lineNumLabel.Text = "line num";
            // 
            // lineTextLabel
            // 
            this.lineTextLabel.AutoSize = true;
            this.lineTextLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lineTextLabel.Location = new System.Drawing.Point(955, 61);
            this.lineTextLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lineTextLabel.Name = "lineTextLabel";
            this.lineTextLabel.Size = new System.Drawing.Size(107, 31);
            this.lineTextLabel.TabIndex = 15;
            this.lineTextLabel.Text = "line text";
            // 
            // rebuildButton
            // 
            this.rebuildButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.rebuildButton.Location = new System.Drawing.Point(761, 508);
            this.rebuildButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rebuildButton.Name = "rebuildButton";
            this.rebuildButton.Size = new System.Drawing.Size(356, 62);
            this.rebuildButton.TabIndex = 16;
            this.rebuildButton.Text = "Rebuild File";
            this.rebuildButton.UseVisualStyleBackColor = true;
            this.rebuildButton.Click += new System.EventHandler(this.rebuildButton_Click);
            // 
            // JournalGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 639);
            this.Controls.Add(this.rebuildButton);
            this.Controls.Add(this.lineTextLabel);
            this.Controls.Add(this.lineNumLabel);
            this.Controls.Add(this.arLabel);
            this.Controls.Add(this.timeLabel);
            this.Controls.Add(this.journalListBox);
            this.Controls.Add(this.openFile);
            this.Controls.Add(this.FolderButton);
            this.Controls.Add(this.RemameButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.PathBox);
            this.Controls.Add(this.DeleteButton);
            this.Controls.Add(this.CreateButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.FileListBox);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "JournalGUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Journaling Software";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.watcher)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox FileListBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button CreateButton;
        private System.Windows.Forms.FolderBrowserDialog rootFolder;
        private System.Windows.Forms.Label PathBox;
        private System.Windows.Forms.Button DeleteButton;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button RemameButton;
        private System.Windows.Forms.Button FolderButton;
        private System.Windows.Forms.Button openFile;
        private System.Windows.Forms.ListBox journalListBox;
        private System.IO.FileSystemWatcher watcher;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.Label arLabel;
        private System.Windows.Forms.Label lineNumLabel;
        private System.Windows.Forms.Label lineTextLabel;
        private System.Windows.Forms.Button rebuildButton;
    }
}

