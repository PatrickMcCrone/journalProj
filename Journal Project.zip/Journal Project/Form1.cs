﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.CompilerServices;
using System.Configuration;
using System.Runtime.InteropServices;
using System.Xml.Linq;
using System.Diagnostics;

namespace Journal
{
    public partial class JournalGUI : Form
    {
        string path = string.Empty;
        string journalPath = string.Empty;
        List<Journal> journals = new List<Journal>();

        public JournalGUI()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //ask the user for the folder to be monitored
            if (rootFolder.ShowDialog() == DialogResult.OK)
            {
                path = rootFolder.SelectedPath;

                PathBox.Text = "Selected Folder: " + path;

                journalPath = path + "\\.journal";
                DirectoryInfo di = Directory.CreateDirectory(journalPath);
                di.Attributes = FileAttributes.Directory | FileAttributes.Hidden;
            }
            else
            {
                this.Close();
                return;
            }

            //create a watcher to monitor the file system
            watcher.Path = path;
            watcher.EnableRaisingEvents = true;
            watcher.Filter = "*.txt";
            watcher.NotifyFilter = NotifyFilters.FileName | NotifyFilters.Size | NotifyFilters.Attributes;
            watcher.Changed += OnChanged;
            watcher.Created += OnCreated;
            watcher.Deleted += OnDeleted;
            watcher.Renamed += OnRenamed;

            //filter to .txt files
            watcher.Filter = "*.txt";
            watcher.IncludeSubdirectories = false;
            watcher.EnableRaisingEvents = true;

            //get the current files in the folder
            var files = Directory.GetFiles(path);
            foreach (var file in files)
            {
                journals.Add(new Journal(file, path));
                FileListBox.Items.Add(Path.GetFileName(file));
            }
        }

        private void OnChanged(object sender, FileSystemEventArgs e)
        {
            if (journals.Where(i => i.FileName == e.FullPath).FirstOrDefault() != null)
            {
                journals.Where(i => i.FileName == e.FullPath).FirstOrDefault().FindDifferences(e.FullPath);
               // MessageBox.Show(journals.Where(i => i.FileName == e.FullPath).FirstOrDefault().FileName);
            }
        }

        private void OnCreated(object sender, FileSystemEventArgs e)
        {
            
            if (e.FullPath.Contains("_rebuild.txt"))
            {
                updateFileListAdd(FileListBox);
                return;
            }
            
            updateFileListAdd(FileListBox);
            //get the file path
            string jfPath = journalPath + "\\" + Path.GetFileName(e.FullPath);
            //if the journal doesn't exist
            if (!File.Exists(jfPath)) 
                journals.Add(new Journal(e.FullPath, path)); //create a new journal
        }

        private void OnDeleted(object sender, FileSystemEventArgs e)
        {
            updateFileListDelete(FileListBox);
            MessageBox.Show($"Deleted: {e.FullPath}", "Deleted File!", MessageBoxButtons.OK);
        }

        private void OnRenamed(object sender, FileSystemEventArgs e)
        {
            updateFileListAdd(FileListBox);
            updateFileListDelete(FileListBox);
            MessageBox.Show($"Renamed: New File Name: {e.FullPath}", "Renamed File!", MessageBoxButtons.OK);
            //get the file path
            string jfPath = journalPath + "\\" + Path.GetFileName(e.FullPath);
            //if the journal doesn't exist
            if (!File.Exists(jfPath))
                journals.Add(new Journal(e.FullPath, path)); //create a new journal
        }

        private void CreateButton_Click(object sender, EventArgs e)
        {
            string name = string.Empty;
            bool exists = true;
            FileStream fs;
            string filePath = string.Empty;
      
            while (exists)
            {
                if (CreateDialogBox("New File", "Please enter the name of the new file.", ref name) == DialogResult.OK)
                {
                    //append file name to path
                    filePath = path + "\\" + name + ".txt";

                    name += ".txt";
                    exists = FileExists(name);
                }
            }

            //create new file
            fs = File.Create(filePath);

            //update listbox
            FileListBox.Items.Add(Path.GetFileName(filePath));
            fs.Close();

        }

        private DialogResult CreateDialogBox(string title, string request, ref string value)
        {
            //Create a new Dialog Box to ask the user for the file name
            Form form = new Form();
            Label label = new Label();
            Label label2 = new Label();
            TextBox textBox = new TextBox();
            Button buttonOK = new Button();
            Font font = new Font(FontFamily.GenericSansSerif, (float)15);

            //set the text to each element
            form.Text = title;
            label.Text = request;
            label2.Text = ".txt";

            //set the font for each element
            label.Font = font;
            label2.Font = font;
            buttonOK.Font = font;

            //set the buttons to ok and cancel
            buttonOK.Text = "OK";
            buttonOK.DialogResult = DialogResult.OK;

            //Place the elements in the dialog box
            label.SetBounds(10, 30, 372, 20);
            label2.SetBounds(280, 60, 40, 20);
            textBox.SetBounds(20, 60, 280, 20);
            buttonOK.SetBounds(30, 100, 140, 30);

            //General size properties
            label.AutoSize = true;
            label2.AutoSize = true;
            form.ClientSize = new Size(350, 150);
            form.FormBorderStyle = FormBorderStyle.FixedDialog;
            form.StartPosition = FormStartPosition.CenterScreen;
            form.MinimizeBox = false;
            form.MaximizeBox = false;

            //allow the elements to show up
            form.Controls.AddRange(new Control[] {label, label2, textBox, buttonOK});
            form.AcceptButton = buttonOK;

            DialogResult dialogResult = form.ShowDialog();

            value = textBox.Text;
            return dialogResult;
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {

            //make sure an item is already selected
            if (FileListBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a file to be deleted!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                //create a path to the file
                string fileName = path + "\\" + FileListBox.SelectedItem.ToString();

                string journalPath = path + "\\.journal\\" + FileListBox.SelectedItem.ToString();
                string newName = path + "\\.journal\\" + Path.GetFileNameWithoutExtension(fileName) + "_bak.txt";

                if (!File.Exists(newName))
                    File.Move(journalPath, newName);
                else
                {
                    MessageBox.Show("A backup of this file already exists, please rename before deleting to preserve a backup!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                //Delete the file
                File.Delete(fileName);

                //Remove the file from the listbox
                FileListBox.Items.Remove(FileListBox.SelectedItem);
            }
            
        }

        private void FileListBox_Selected(object sender, EventArgs e)
        {
            journalListBox.Items.Clear();

            //Check if an item is selected to avoid Exeption
            if (FileListBox.SelectedIndex != -1)
            {
                //get the file name and open a FS
                string fileName = journalPath + "\\" + FileListBox.SelectedItem.ToString();
                
                StreamReader sr = new StreamReader(fileName);
                string line = sr.ReadLine();
                while(!sr.EndOfStream)
                {
                    journalListBox.Items.Add(sr.ReadLine());
                }
                sr.Close();
            }
        }

        private void RemameButton_Click(object sender, EventArgs e)
        {
            //Check if a file is selected
            if (FileListBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a file to be renamed!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string name = string.Empty;
                bool exists = true;
                string filePath = string.Empty;
                string oldName = path + "\\" + FileListBox.SelectedItem.ToString();
                string oldJournal = path + "\\.journal\\" + FileListBox.SelectedItem.ToString();
                string newJournal = path + "\\.journal\\";

                //while loop to check if the file name exists
                while (exists)
                {
                    //Create a dialog box to ask the user what to rename the file to
                    if (CreateDialogBox("Rename File", "Please enter the name of the new file.", ref name) == DialogResult.OK)
                    {
                        //append file naem to path
                        filePath = path + "\\" + name + ".txt";
                        newJournal += name + ".txt";

                        //check if the file already exists
                        name += ".txt";
                        exists = FileExists(name);
                    }
                }

                File.Move(oldName, filePath);
                File.Move(oldJournal, newJournal);
                FileListBox.Items.Add(Path.GetFileName(filePath));
                FileListBox.Items.Remove(FileListBox.SelectedItem);
            }
        }

        private bool FileExists(string name)
        {
            //loop through each item in listbox
            foreach (string s in FileListBox.Items)
            {
                //if the file exists return true
                if (s == name)
                {
                    MessageBox.Show("This file name already exists, please enter a new name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return true;
                }
            }
            return false;
        }

        private void FolderButton_Click(object sender, EventArgs e)
        {
            Process.Start("explorer.exe", journalPath);
        }

        private void openFile_Click(object sender, EventArgs e)
        {
            //chekc if something is selected
            if (FileListBox.SelectedIndex == -1)
                MessageBox.Show("Please select a file to be opened", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                //create a path
                string fileName = path + "\\" + FileListBox.SelectedItem.ToString();

                //start notepad
                Process.Start("notepad.exe", fileName);
            }
        }

        private void rebuildFile_Click(object sender, EventArgs e)
        {
        }
        void updateFileListAdd(ListBox fileList)
        {
            string[] files = Directory.GetFiles(path);
            foreach (string file in files)
            {
                if (fileList.Items.Contains(Path.GetFileName(file)))
                {
                    continue;
                }
                else
                {
                    fileList.Items.Add(Path.GetFileName(file));
                }
            }
        }
        void updateFileListDelete(ListBox fileList)
        {
            fileList.Items.Clear();
            string[] files = Directory.GetFiles(path);

            foreach ( string file in files )
            {
                FileListBox.Items.Add(Path.GetFileName(file));
            }
        }

        private void rebuildButton_Click(object sender, EventArgs e)
        {
            if (journalListBox.SelectedIndex != -1)
            {
                //get the file name and open a FS
                string fileName = journalPath + "\\" + FileListBox.SelectedItem.ToString();
                string rebuildFileName = Path.GetFileNameWithoutExtension(fileName) + "_rebuild.txt";
                string newPath = path + "\\" + rebuildFileName;
                File.Create(newPath).Close();

                char[] separator = new char[] { '\t' };
                string[] strings;
                bool b;
                StreamWriter sw = new StreamWriter(newPath);

                for (int i = journalListBox.SelectedIndex; i < journalListBox.Items.Count; i++)
                {
                    strings = journalListBox.Items[i].ToString().Split(separator, StringSplitOptions.RemoveEmptyEntries);
                    b = bool.Parse(strings[1]);

                    if (b)
                    {
                        //MessageBox.Show(strings[3]);
                        sw.WriteLine(strings[3]);
                    }

                }
                sw.Close();
                
            }
            else
            {
                MessageBox.Show("Please select a valid journal line", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

