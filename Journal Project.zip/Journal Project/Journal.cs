﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Journal
{
    internal class Journal
    {
        public List<JournalEntry> entries;
        private FileStream fs;
        private string fileName;
        private string p;

        public Journal(string fileName, string path) 
        {
            //create new list of journal entries for the file
            entries = new List<JournalEntry>();
            this.fileName = fileName;
            
            //append hidden folder and filename to path
            path += "\\.journal\\";

            p = path;
            path += Path.GetFileName(fileName);

            //check if file exists and create one if it doesnt
            if (!File.Exists(path))
            {
                fs = File.Create(path);
                fs.Close();
            }
            
            //check if file is empty
            if (new FileInfo(path).Length == 0)
            {
                //create header
                File.WriteAllText(path, "time\t\t\t\ta/r\t\tline num\t\tline\n");
            }
            else
            {
                ParseJournal(path);
            }
        }

        public string FileName { get { return fileName; } set { fileName = value; } }


        public void AddEntry(bool added, string line, int lineNum)
        {
            entries.Add(new JournalEntry(added, line, lineNum));
        }

        public List<string> ParseJournal(string filePath)
        {
            List<string> jn = new List<string>();

            StreamReader sr = new StreamReader(filePath);
            while (!sr.EndOfStream)
            {
                char[] separator  = new char[] { '\t' }; 
                string[] s;
                string l;
                string s1, s2;
                bool b;
                int i;
                l = sr.ReadLine();

                
                s = l.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                if (s.Count() > 3)
                {
                    if (s[3] != "line")
                    {
                        s1 = s[0];
                        b = Boolean.Parse(s[1]);
                        i = int.Parse(s[2]);
                        s2 = s[3];

                        //MessageBox.Show(s1 + " " + b.ToString() + " " + i.ToString() + " " + s2);
                        entries.Add(new JournalEntry(s1, b, s2, i));
                    }
                }
            }

            sr.Close();

            return jn;
        }

        private void _RecreateFile(string filePath)
        {
            List<JournalEntry> sortedEntries = entries.OrderBy(o => o.LineNum).ToList();
            int num = 1, count = sortedEntries.Count, i = 1;
            sortedEntries.Add(new JournalEntry(true, "", -1));
            string line = string.Empty;
            StreamWriter sw = new StreamWriter(filePath);

            foreach (JournalEntry entry in sortedEntries)
            {
                //check if we're on a new line
                if (entry.LineNum != num || entry.LineNum == -1)
                {
                    if (line != string.Empty)
                    {
                        //MessageBox.Show("Writing: " + line);
                        sw.WriteLine(line);
                    }
                    line = string.Empty;
                    num++;
                }
                else
                {
                    //check if we're adding or removing a line
                    if (entry.AddRemove)
                        line = entry.Line;
                    else
                        line = string.Empty;
                    //MessageBox.Show(line + "\n" + num.ToString() + "\n" + count + "\n" + i);
                    i++;
                }
            }

            //sortedEntries.Remove(sortedEntries.Last());
            sw.Close();
        }

        

        public void FindDifferences(string path)
        {
            string newPath = p + "tmp.txt";

            //Create a temp file
            FileStream fs;
            fs = File.Create(newPath);
            fs.Close();
            _RecreateFile(newPath);

            //Read line by line
            StreamReader sr1 = new StreamReader(path);
            StreamReader sr2 = new StreamReader(newPath);

            string s1 = string.Empty, s2 = string.Empty;
            int num = 1;

            while (!sr1.EndOfStream)
            {
                s1 = sr1.ReadLine();
                s2 = sr2.ReadLine();
                // MessageBox.Show(s1 + "\n" + s2);

                if (s1 != s2)
                {
                    if (s2 != null)
                    {
                        AddEntry(false, s2, num);
                        WriteToJournal(entries.Last());
                        AddEntry(true, s1, num);
                        WriteToJournal(entries.Last());
                    }
                    else
                    {
                        AddEntry(true, s1, num);
                        WriteToJournal(entries.Last());
                    }
                }
                else
                {
                    num++;
                    continue;
                }
                num++;
            }

            /*if (!sr2.EndOfStream)
            {
                AddEntry(false, "ERROR", num);
                WriteToJournal(entries.Last());
                num++;
            }*/

            sr1.Close();
            sr2.Close();

            File.Delete(newPath);
        }

        private void WriteToJournal(JournalEntry entry)
        {
            string filePath = p + Path.GetFileName(fileName);
            StreamWriter sw = new StreamWriter(filePath, true);
            string line = string.Empty;
            if (entry.AddRemove)
                line = entry.TimeStamp + "\t\t" + entry.AddRemove.ToString() + "\t\t\t" + entry.LineNum.ToString() + "\t\t" + entry.Line;
            else
                line = entry.TimeStamp + "\t\t" + entry.AddRemove.ToString() + "\t\t\t" + entry.LineNum.ToString() + "\t\t" + entry.Line;


            sw.WriteLine(line);
            sw.Close();
        }

    }
}
