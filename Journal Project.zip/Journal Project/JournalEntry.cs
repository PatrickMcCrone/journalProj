﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Journal
{
    internal class JournalEntry
    {
        private string timeStamp;
        private bool added;
        private string line;
        private int lineNum;
        private string fileName;
        private FileStream fs;

        public JournalEntry(string timeStamp, bool added, string line, int lineNum)
        {
            this.timeStamp = timeStamp;
            this.added = added;
            this.line = line;
            this.lineNum = lineNum;
        }

        public JournalEntry(bool added, string line, int lineNum)
        {
            timeStamp = DateTime.Now.ToString("u");
            timeStamp = timeStamp.Remove(timeStamp.Length - 1, 1);
            this.added = added;
            this.line = line;
            this.lineNum = lineNum;
        }

        public string TimeStamp { get { return timeStamp; } }

        public bool AddRemove { get { return added; } }

        public string Line { get { return line; } }

        public string FileName { get {  return fileName; } }

        public int LineNum { get {  return lineNum; } }
    }
}
